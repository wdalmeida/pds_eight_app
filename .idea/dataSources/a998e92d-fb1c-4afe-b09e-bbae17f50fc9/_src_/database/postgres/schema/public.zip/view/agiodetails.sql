CREATE VIEW agiodetails AS SELECT (row_number() OVER (ORDER BY client.id_client))::integer AS id,
    client.id_client,
    account.id_account,
    status.name_status,
    client.name,
    abs(sum(balance.balance)) AS overdraftamount,
    count(balance.balance) AS nbdayagio,
    param_agios.rate_agios,
    status.overdraft,
    status.id_status,
    account.iban_bban,
    account.iban_cc,
    account.iban_cp
   FROM client,
    status,
    account,
    balance,
    param_agios
  WHERE ((client.id_client = account.id_client) AND (balance.id_account = account.id_account) AND (client.id_categorie = status.id_status) AND (balance.balance < (0)::double precision) AND (status.id_status = param_agios.id_cat) AND (balance.etat = false))
  GROUP BY client.id_client, account.id_account, status.name_status, status.overdraft, param_agios.rate_agios, status.id_status, account.iban_bban, account.iban_cc, account.iban_cp;
